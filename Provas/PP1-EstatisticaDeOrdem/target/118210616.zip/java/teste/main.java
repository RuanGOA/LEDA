package teste;

import problems.OrderStatisticsSortedUnion;

public class main {

	public static void main(String[] args) {
		Integer[] arr = new Integer[] {};
		Integer[] arr2 = new Integer[] {};
		
		OrderStatisticsSortedUnion order = new OrderStatisticsSortedUnion<>();
		
		System.out.println(order.statisticsOrder(arr, arr2, 10));
	}
	
	
	
	
}
